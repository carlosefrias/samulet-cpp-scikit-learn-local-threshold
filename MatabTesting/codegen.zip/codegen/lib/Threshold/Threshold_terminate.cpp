/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Threshold_terminate.cpp
 *
 * Code generation for function 'Threshold_terminate'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "Threshold.h"
#include "Threshold_terminate.h"

/* Function Definitions */
void Threshold_terminate()
{
  /* (no terminate code required) */
}

/* End of code generation (Threshold_terminate.cpp) */
