/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * useConstantDim.h
 *
 * Code generation for function 'useConstantDim'
 *
 */

#ifndef USECONSTANTDIM_H
#define USECONSTANTDIM_H

/* Include files */
#include <stddef.h>
#include <stdlib.h>
#include "rtwtypes.h"
#include "Threshold_types.h"

/* Function Declarations */
extern void useConstantDim(emxArray_real_T *varargin_2, int varargin_3);

#endif

/* End of code generation (useConstantDim.h) */
