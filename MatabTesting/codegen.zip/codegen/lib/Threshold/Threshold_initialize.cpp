/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * Threshold_initialize.cpp
 *
 * Code generation for function 'Threshold_initialize'
 *
 */

/* Include files */
#include "rt_nonfinite.h"
#include "Threshold.h"
#include "Threshold_initialize.h"

/* Function Definitions */
void Threshold_initialize()
{
  rt_InitInfAndNaN(8U);
}

/* End of code generation (Threshold_initialize.cpp) */
